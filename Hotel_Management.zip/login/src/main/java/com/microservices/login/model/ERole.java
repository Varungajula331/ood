package com.microservices.login.model;

public enum ERole {
	ROLE_OWNER, ROLE_MANAGER, ROLE_RECEPTIONIST
}
